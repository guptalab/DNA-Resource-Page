export const oxfordAcademic = {
    sourceName: "Oxford Academic",
    sourceUrl: "https://academic.oup.com/search-results?q=dna+storage&fl_SiteID=191&page=1",
    articleUrlSelector:".al-citation-list > span > a",
    selector: {
        articleTitleSelector: ".wi-article-title.article-title-main.accessible-content-title.at-articleTitle",
        articlePublishDateSelector: ".citation-date",
    }
}

export const mdpi = {
    sourceName: "MDPI",
    sourceUrl: "https://www.mdpi.com/search?q=dna&journal=electronics",
    articleUrlSelector:".article-content > .color-grey-dark > a",
    selector: {
        articleTitleSelector: ".title.hypothesis_container",
        articlePublishDateSelector: ".pubhistory > span",
    }
}

export const engadget = {
    sourceName: "engadget",
    sourceUrl: "https://tinyurl.com/3693jxhs",
    articleUrlSelector:".pb-10 > a",
    selector: {
        articleTitleSelector: ".caas-title-wrapper > h1",
        articlePublishDateSelector: ".caas-attr-time-style > time",
    }
}

export const sciTechDaily = {
    sourceName: "SciTechDaily",
    sourceUrl: "https://scitechdaily.com/?s=dna+storage",
    articleUrlSelector:".entry-title.content-list-title > a",
    selector: {
        articleTitleSelector: ".entry-title",
        articlePublishDateSelector: ".entry-meta > .entry-meta-date.updated",
    }
}

export const scienceDirect = {
    sourceName: "ScienceDirect",
    sourceUrl: "https://www.sciencedirect.com/search?qs=dna+storage",
    articleUrlSelector:".anchor.result-list-title-link.u-font-serif.text-s.anchor-default",
    selector: {
        articleTitleSelector: ".title-text",
        articlePublishDateSelector: ".text-s",
    }
}

export const springerLink = {
    sourceName: "SpringerLink",
    sourceUrl: "https://link.springer.com/search?query=dna+storage&facet-content-type=%22Article%22",
    articleUrlSelector:".title",
    selector: {
        articleTitleSelector: ".c-article-title",
        articlePublishDateSelector: ".c-article-identifiers__item > a > time",
    }
}