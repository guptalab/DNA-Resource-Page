import { setTimeout } from 'timers/promises';

class Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        this.browser = browser;
        this.sourceName = sourceName;
        this.sourceUrl = sourceUrl;
        this.articleUrlSelector = articleUrlSelector;
        this.selector = {
            articleTitleSelector,
            articlePublishDateSelector,
        }
    }

    getTitle = async (page) => {
        try {
            await page.waitForSelector(this.selector.articleTitleSelector);
    
            const title = await page.$eval(this.selector.articleTitleSelector, el => el.innerText);
    
            return title;
    
        } catch (error) {
            throw new Error(error);
        }
    }

    getPublishDate = async (page) => {
        try {
            await page.waitForSelector(this.selector.articlePublishDateSelector);
        
            const date = await page.$eval(this.selector.articlePublishDateSelector, el => el.innerText);
        
            return date;
            
        } catch (error) {
            throw new Error(error);
        }
    }

    scrape = async () => {
        try {
            const page = await this.browser.newPage();
            await page.goto(this.sourceUrl,{
                waitUntil: "load",
                timeout: 0
            });
            await page.waitForSelector(this.articleUrlSelector);
        
            const articleLinks = await page.$$eval(this.articleUrlSelector, links => {
                return links.map(link => link.href);
            });
    
            const articles = []
        
            for(let i = 0; i < articleLinks.length; i++){
                const newPage = await this.browser.newPage();
                const status = await newPage.goto(articleLinks[i],{
                    waitUntil: "load",
                    timeout: 0
                });
                console.log(articleLinks[i],status.status());
                if (status.status() !== 200) continue;
                try {
                    const title = await this.getTitle(newPage);
                    const date = await this.getPublishDate(newPage);
                    articles.push({source:this.sourceName,title, publishDate: date, link: articleLinks[i]});
                } catch (error) {
                    console.log(error);
                }
                // sleep thread for some time to avoid rate limit
                await setTimeout(3000);
            }

            return articles;
        } catch (error) {
            console.log(error);
            return [];
        }
    }

}

export class OxfordAcademicScrapper extends Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }
}

export class MDPIScrapper extends Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }

    getPublishDate = async (page) => {
        try {
            await page.waitForSelector(this.selector.articlePublishDateSelector);
    
            const spans = await page.$$eval(this.selector.articlePublishDateSelector, spans => {
                return spans.map(span => span.innerText);
            });
    
            const date = spans[spans.length - 1].substring(11);
    
            return date;
    
        } catch (error) {
            throw new Error(error);
        }
    }
}

export class EnGadgetScrapper extends Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }

    getPublishDate = async (page) => {
        try {
            await page.waitForSelector(this.selector.articlePublishDateSelector);
        
            const date = await page.$eval(this.selector.articlePublishDateSelector, el => el.innerText);
        
            return date.substring(5);
            
        } catch (error) {
            throw new Error(error);
        }
    }
} 

export class SciTechDailyScrapper extends Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }
}

export class ScienceDirectScrapper extends Scrapper {
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }

    getPublishDate = async (page) => {
        try {
            await page.waitForSelector(this.selector.articlePublishDateSelector);
    
            const text = await page.$eval(this.selector.articlePublishDateSelector, p => p.innerText);

            const date = text.split(",")[2].substring(10);
    
            return date;
    
        } catch (error) {
            throw new Error(error);
        }
    }
}

export class SpringerLinkScrapper extends Scrapper{
    constructor(browser,sourceName,sourceUrl,articleUrlSelector,{
        articleTitleSelector,
        articlePublishDateSelector,
    }){
        super(browser,sourceName,sourceUrl,articleUrlSelector,{
            articleTitleSelector,
            articlePublishDateSelector,
        })
    }
}
