import puppeteer from "puppeteer";
import fs from "fs";
import { oxfordAcademic, mdpi, engadget, sciTechDaily, scienceDirect,springerLink } from "./constants.js";
import { OxfordAcademicScrapper, MDPIScrapper, EnGadgetScrapper, SciTechDailyScrapper, ScienceDirectScrapper,SpringerLinkScrapper } from "./scrapper.js";


const main = async () => {
    try {
        const browser = await puppeteer.launch({ headless: "new" });
        const scrappers = [];
        scrappers.push(new OxfordAcademicScrapper(browser, oxfordAcademic.sourceName, oxfordAcademic.sourceUrl, oxfordAcademic.articleUrlSelector, oxfordAcademic.selector));
        scrappers.push(new MDPIScrapper(browser, mdpi.sourceName, mdpi.sourceUrl, mdpi.articleUrlSelector, mdpi.selector));
        scrappers.push(new EnGadgetScrapper(browser, engadget.sourceName, engadget.sourceUrl, engadget.articleUrlSelector, engadget.selector));
        scrappers.push(new SciTechDailyScrapper(browser, sciTechDaily.sourceName, sciTechDaily.sourceUrl, sciTechDaily.articleUrlSelector, sciTechDaily.selector));
        scrappers.push(new ScienceDirectScrapper(browser, scienceDirect.sourceName, scienceDirect.sourceUrl, scienceDirect.articleUrlSelector, scienceDirect.selector));
        scrappers.push(new SpringerLinkScrapper(browser, springerLink.sourceName, springerLink.sourceUrl, springerLink.articleUrlSelector, springerLink.selector));
        const writeStream = fs.createWriteStream("articles.json");
        writeStream.write("[");
        let first = true;
        for(let scrapper of scrappers){
            const articles = await scrapper.scrape();
            articles.forEach(article => {
                if(!first){
                    writeStream.write(",");
                }
                writeStream.write(JSON.stringify(article));
                first = false;
            });
        }
        writeStream.write("]");
        await browser.close();
    } catch (error) {
        console.log(error);
    }
}

const temp = async() => {
    const data = fs.readFileSync("articles.json");
    const articles = JSON.parse(data);
    console.log(articles.length);
}

// main();
temp();